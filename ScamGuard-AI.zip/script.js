function checkURL(){
let url=document.getElementById('url').value;
let score=0;
if(url.includes('@')) score+=30;
if(url.includes('-')) score+=20;
if(url.length>50) score+=20;
if(url.includes('login')||url.includes('verify')) score+=30;
document.getElementById('urlResult').innerText =
score>=50 ? '⚠ Suspicious URL' : '✅ Appears Safe';
}

function checkPassword(){
let p=document.getElementById('password').value;
let score=0;
if(p.length>=8) score++;
if(/[A-Z]/.test(p)) score++;
if(/[a-z]/.test(p)) score++;
if(/[0-9]/.test(p)) score++;
if(/[^A-Za-z0-9]/.test(p)) score++;
const levels=['Very Weak','Weak','Moderate','Strong','Very Strong'];
document.getElementById('passResult').innerText='Strength: '+levels[Math.min(score,4)];
}