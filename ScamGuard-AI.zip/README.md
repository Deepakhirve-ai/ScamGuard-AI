# ScamGuard AI

Cyber Security mini project with phishing URL detection and password strength analysis.
